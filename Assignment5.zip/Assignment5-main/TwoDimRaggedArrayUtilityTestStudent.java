import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.Math;

class TwoDimRaggedArrayUtilityTestStudent {

	double[][] arr =
		{{1.65, 4.50, 2.36, 7.45, 3.44, 6.23},
		{2.22, -3.24, -1.66, -5.48, 3.46},
		{4.23, 2.29, 5.29},
		{2.76, 3.76, 4.29, 5.48, 3.43},
		{3.38, 3.65, 3.76},
		{2.46, 3.34, 2.38, 8.26, 5.34}};
	
	@Test
	void testGetTotal() {
		assertTrue(TwoDimRaggedArrayUtility.getTotal(arr) == 85.03);
	}

	@Test
	void testGetAverage() {
		assertTrue(Math.floor(TwoDimRaggedArrayUtility.getAverage(arr)) == 3);
	}

	@Test
	void testGetHighestInArray() {
		assertTrue(TwoDimRaggedArrayUtility.getHighestInArray(arr) == 8.26);
	}

	@Test
	void testGetLowestInArray() {
		assertTrue(TwoDimRaggedArrayUtility.getLowestInArray(arr) == -5.48);
	}

	@Test
	void testGetRowTotal() {
		assertTrue(Math.round(TwoDimRaggedArrayUtility.getRowTotal(arr,2) * 100.0) / 100.0 == 11.81);
	}

	@Test
	void testGetHighestInRow() {
		assertTrue(TwoDimRaggedArrayUtility.getHighestInRow(arr,0) == 7.45);
	}

	@Test
	void testGetHighestInRowIndex() {
		assertTrue(TwoDimRaggedArrayUtility.getHighestInRowIndex(arr,0) == 3);
	}

	@Test
	void testGetLowestInRow() {
		assertTrue(TwoDimRaggedArrayUtility.getLowestInRow(arr,2) == 2.29);
	}

	@Test
	void testGetLowestInRowIndex() {
		assertTrue(TwoDimRaggedArrayUtility.getLowestInRowIndex(arr,4) == 0);
	}

	@Test
	void testGetColumnTotal() {
		assertTrue(Math.round(TwoDimRaggedArrayUtility.getColumnTotal(arr,1) * 100.0) / 100.0 == 14.30);
	}

	@Test
	void testGetHighestInColumn() {
		assertTrue(TwoDimRaggedArrayUtility.getHighestInColumn(arr,0) == 4.23);
	}

	@Test
	void testGetHighestInColumnIndex() {
		assertTrue(TwoDimRaggedArrayUtility.getHighestInColumnIndex(arr,1) == 0);
	}

	@Test
	void testGetLowestInColumn() {
		assertTrue(TwoDimRaggedArrayUtility.getLowestInColumn(arr,2) == -1.66);
	}

	@Test
	void testGetLowestInColumnIndex() {
		System.out.println(TwoDimRaggedArrayUtility.getLowestInColumnIndex(arr,3));
		assertTrue(TwoDimRaggedArrayUtility.getLowestInColumnIndex(arr,3) == 1);
	}

	@Test
	void testReadFile() {
		File file = new File("file.txt");
		try {
			TwoDimRaggedArrayUtility.writeToFile(arr, file);
			double[][] a = TwoDimRaggedArrayUtility.readFile(file);
			for (int i=0;i<a.length;i++)
				for(int j=0;j<a[i].length;j++)
					assertTrue(arr[i][j] == a[i][j]);
		}
		catch (FileNotFoundException e){
			fail("This should not have caused an Exception");
		}
	}

	@Test
	void testWriteToFile(){
		File file = new File("file.txt");
		try {
			TwoDimRaggedArrayUtility.writeToFile(arr, file);
			double[][] a = TwoDimRaggedArrayUtility.readFile(file);
			for (int i=0;i<a.length;i++)
				for(int j=0;j<a[i].length;j++)
					assertTrue(arr[i][j] == a[i][j]);
		}
		catch (FileNotFoundException e){
			fail("This should not have caused an Exception");
		}		
	}
}
