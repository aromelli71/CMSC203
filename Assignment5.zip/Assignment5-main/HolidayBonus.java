/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description: Calculate and display sales information for a store district
 * Due: 11/07/2022
 * Platform/compiler: Eclipse (Java)
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/

public class HolidayBonus{
	
	public static final int HIGHEST_BONUS = 5000, LOWEST_BONUS = 1000, OTHER_BONUS = 2000;
	
	public HolidayBonus() {}
	
	public static double[] calculateHolidayBonus(double[][] data){
		double[][] bonus =  new double[data.length][];
		for(int row=0;row<bonus.length;row++)
			bonus[row] = new double[data[row].length];
		for(int col=0;col<bonus.length;col++) {
			for (int row=0;row<data.length;row++) {
				if(col<bonus[row].length) {
					if (data[row][col] == TwoDimRaggedArrayUtility.getHighestInColumn(data,col))
						bonus[row][col] = HIGHEST_BONUS;
					else if (data[row][col] == TwoDimRaggedArrayUtility.getLowestInColumn(data,col))
						bonus[row][col] = LOWEST_BONUS;
					else bonus[row][col] = OTHER_BONUS;
				}
			}
		}
		double[] bonusPerStore =  new double[data.length];
		for(int row=0;row<bonus.length;row++)
			for(int col= 0;col<bonus[row].length;col++)
				bonusPerStore[row] += bonus[row][col];
		return bonusPerStore;
	}

	public static double calculateTotalHolidayBonus(double[][] data){
		double[][] bonus =  new double[data.length][];
		for(int row=0;row<bonus.length;row++)
			bonus[row] = new double[data[row].length];
		for(int col=0;col<bonus.length;col++) {
			for (int row=0;row<data.length;row++) {
				if(col<bonus[row].length) {
					if (data[row][col] == TwoDimRaggedArrayUtility.getHighestInColumn(data,col))
						bonus[row][col] = HIGHEST_BONUS;
					else if (data[row][col] == TwoDimRaggedArrayUtility.getLowestInColumn(data,col))
						bonus[row][col] = LOWEST_BONUS;
					else bonus[row][col] = OTHER_BONUS;
				}
			}
		}
		double total = 0.0;
		for(int row=0;row<bonus.length;row++){
			for(int col=0;col<bonus[row].length;col++){
				total += bonus[row][col];
			}
		}
		return total;
	}
}