import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class HolidayBonusTestStudent {

	double[][] arr =
		{{1.65, 4.50, 2.36, 7.45, 3.44, 6.23},
		{2.22, -3.24, -1.66, -5.48, 3.46},
		{4.23, 2.29, 5.29},
		{2.76, 3.76, 4.29, 5.48, 3.43},
		{3.38, 3.65, 3.76},
		{2.46, 3.34, 2.38, 8.26, 5.34}};


	@Test
	void testCalculateHolidayBonus() {
		double[] output = HolidayBonus.calculateHolidayBonus(arr);
		assertTrue(output[0] == 17000);
		assertTrue(output[1] == 7000);
		assertTrue(output[2] == 12000);
		assertTrue(output[3] == 9000);
		assertTrue(output[4] == 6000);
		assertTrue(output[5] == 16000);
	}
	
	@Test
	void testCalculateTotalHolidayBonus(){
		assertTrue(HolidayBonus.calculateTotalHolidayBonus(arr) == 67000);
	}

}
