/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description: Calculate and display sales information for a store district
 * Due: 11/07/2022
 * Platform/compiler: Eclipse (Java)
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;

class TwoDimRaggedArrayUtility {
	
	public TwoDimRaggedArrayUtility() {}

	public static double getTotal(double[][] data) {
		double total = 0;
		for (int row=0;row<data.length;row++)
			for (int col=0;col<data[row].length;col++)
				total += data[row][col];
		return total;
	}
	public static double getAverage(double[][] data) {
		double total = 0;
		int elements = 0;
		for (int row=0;row<data.length;row++)
			for (int col=0;col<data[row].length;col++) {
				total += data[row][col];
				elements++;
			}
		return (total / elements);
	}	
	public static double getHighestInArray(double[][] data) {
		double highest = -Double.MAX_VALUE;
		for (int row=0;row<data.length;row++)
			for (int col=0;col<data[row].length;col++)
				if (data[row][col] > highest)
					highest = data[row][col];
		return highest;
	}
	public static double getLowestInArray(double[][] data) {
		double lowest = Double.MAX_VALUE;
		for (int row=0;row<data.length;row++)
			for (int col=0;col<data[row].length;col++)
				if (data[row][col] < lowest)
					lowest = data[row][col];
		return lowest;
	}

	public static double getRowTotal(double[][] data, int index) {
		double total = 0;
		for (int col=0;col<data[index].length;col++)
			total += data[index][col];
		return total;
	}
	public static double getHighestInRow(double[][] data, int index) {
		double highest = -Double.MAX_VALUE;
		for (int col=0;col<data[index].length;col++)
			if (data[index][col] > highest)
				highest = data[index][col];
		return highest;
	}
	public static int getHighestInRowIndex(double[][] data, int row) {
		int index = 0;
		for (int col=0;col<data[row].length; col++)
			if (data[row][col] > data[row][index])
				index = col;
		return index;
	}
	public static double getLowestInRow(double[][] data, int index) {
		double lowest = Double.MAX_VALUE;
		for (int col=0;col<data[index].length;col++)
			if (data[index][col] < lowest)
				lowest = data[index][col];
		return lowest;
	}
	public static int getLowestInRowIndex(double[][] data, int row) {
		int index = 0;
		for (int col=0;col<data[row].length; col++)
			if (data[row][col] < data[row][index])
				index = col;
		return index;
	}
	
	public static double getColumnTotal(double[][] data, int index) {
		double total = 0;
		for (int row=0;row<data.length;row++)
			if (index < data[row].length)
				total += data[row][index];
		return total;
	}
	public static double getHighestInColumn(double[][] data, int index) {
		double highest = -Double.MAX_VALUE;
		for (int row=0;row<data.length;row++)
			if (index < data[row].length && data[row][index] > highest)
					highest = data[row][index];
		return highest;
	}
	public static int getHighestInColumnIndex(double[][] data, int col) {
		int index=0;
		for (int row=0;row<data.length;row++)
			if (data[row].length > col) {
				index = row;
				break;
			}
		for (int row=0;row<data.length;row++)
			if (data[row].length > col && data[row][col] > data[index][col])
					index = row;
		return index;
	}
	public static double getLowestInColumn(double[][] data, int index) {
		double lowest = Double.MAX_VALUE;
		for (int row=0;row<data.length;row++)
			if (index < data[row].length && data[row][index] < lowest)
					lowest = data[row][index];
		return lowest;
	}
	public static int getLowestInColumnIndex(double[][] data, int col) {
		int index = 0;
		for (int row=0;row<data.length;row++)
			if (data[row].length > col) {
				index = row;
				break;
			}
		for (int row=0;row<data.length;row++)
			if (col < data[row].length && data[row][col] < data[index][col])
					index = row;
		return index;
	}

	public static double[][] readFile(File file) throws FileNotFoundException {
		double[][] data = new double[6][];
		int row=0;
		Scanner sc = new Scanner(file);
		while (sc.hasNextLine()) {
			String[] temp = sc.nextLine().split(" ");
			data[row] = new double[temp.length];
			for (int col=0;col<temp.length;col++)
				data[row][col] = Double.parseDouble(temp[col]);
			row++;
		}
		sc.close();
		return data;
	}
	public static void writeToFile(double[][] data, File file) throws FileNotFoundException {
		PrintWriter pw = new PrintWriter(file);
		for (int row=0;row<data.length;row++) {
			for (int col=0;col<data[row].length;col++) {
				pw.printf("%.2f ",data[row][col]);
			}
			pw.println();
		}
		pw.close();
	}
}
