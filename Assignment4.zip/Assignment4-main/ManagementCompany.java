/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description: Hold information & processes for a management company which contains an array of properties and a plot
 * Due: 10/24/2022
 * Platform/compiler: Eclipse IDE - Java
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/

public class ManagementCompany {
	// Fields
	public static final int MAX_PROPERTY = 5;
	public static final int MGMT_DEPTH = 10;
	public static final int MGMT_WIDTH = 10;
	
	private String name, taxID;
	private double mgmFeePer;
	private Property[] properties;
	private Plot plot;
	private int numberOfProperties;
	
	//Constructors
	public ManagementCompany() {
		name = taxID = "";
		mgmFeePer = numberOfProperties = 0;
		properties = new Property[MAX_PROPERTY];
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
	}
	public ManagementCompany(String name, String taxID, double mgmFeePer) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFeePer;
		numberOfProperties = 0;
		properties = new Property[MAX_PROPERTY];
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
	}
	public ManagementCompany(String name, String taxID, double mgmFeePer, int x, int y, int width, int depth) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFeePer;
		numberOfProperties = 0;
		properties = new Property[MAX_PROPERTY];
		plot = new Plot(x, y, width, depth);
	}
	public ManagementCompany(ManagementCompany otherCompany) {
		name = otherCompany.getName();
		taxID = otherCompany.getTaxID();
		numberOfProperties = otherCompany.getPropertiesCount();
		mgmFeePer = otherCompany.getMgmFeePer();
		plot = new Plot(otherCompany.getPlot());
		properties = new Property[5];
		for (int i=0;i<otherCompany.getPropertiesCount();i++) {
			if (otherCompany.getProperties()[i] != null) {
				properties[i] = new Property(otherCompany.getProperties()[i]);
			}
		}
	}
	
	//Setters / Getters
	public String getName() {
		return name;
	}
	public String getTaxID() {
		return taxID;
	}
	public double getMgmFeePer() {
		return mgmFeePer;
	}
	public Property[] getProperties() {
		return properties;
	}
	public Plot getPlot() {
		return plot;
	}
	public int getPropertiesCount() {
		return numberOfProperties;
	}
	

	// Methods
	public int addProperty(String name, String city, double rent, String owner) {
		if (numberOfProperties ==5) {
			return -1;
		}
		properties[numberOfProperties] = new Property(name,city,rent,owner);
		if (properties[numberOfProperties] == null) {
			return -2;
		}
		if (!plot.encompasses(properties[numberOfProperties].getPlot())) {
			return -3;
		}
		for (int i=0;i<numberOfProperties;i++) {
			if (properties[i].getPlot().overlaps(properties[numberOfProperties].getPlot())) {
				return -4;
			}
		}
		numberOfProperties++;
		return (numberOfProperties - 1);
	}
	public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
		if (numberOfProperties ==5) {
			return -1;
		}
		properties[numberOfProperties] = new Property(name,city,rent,owner,x,y,width,depth);
		if (properties[numberOfProperties] == null) {
			return -2;
		}
		if (!plot.encompasses(properties[numberOfProperties].getPlot())) {
			return -3;
		}
		for (int i=0;i<numberOfProperties;i++) {
			if (properties[i].getPlot().overlaps(properties[numberOfProperties].getPlot())) {
				return -4;
			}
		}
		numberOfProperties++;
		return (numberOfProperties - 1);
	}
	public int addProperty(Property property) {
		if (numberOfProperties == 5) {
			return -1;
		}
		properties[numberOfProperties] = new Property(property);
		if (properties[numberOfProperties] == null) {
			return -2;
		}
		if (!plot.encompasses(properties[numberOfProperties].getPlot())) {
			return -3;
		}
		for (int i=0;i<numberOfProperties;i++) {
			if (properties[i].getPlot().overlaps(properties[numberOfProperties].getPlot())) {
				return -4;
			}
		}
		numberOfProperties++;
		return (numberOfProperties - 1);
	}
	public Property getHighestRentPropperty() {
		double highestRent=0;
		Property highestRentProperty = null;
		for (int i=0;i<numberOfProperties;i++) {
			if (properties[i].getRentAmount() > highestRent) {
				highestRent = properties[i].getRentAmount();
				highestRentProperty = properties[i];
			}
		}
		return (new Property(highestRentProperty));
	}
	public double getTotalRent() {
		double totalRent = 0;
		for (int i=0;i<numberOfProperties;i++) {
			totalRent += properties[i].getRentAmount();
		}
		return totalRent;
	}
	public boolean isManagementFeeValid() {
		return (mgmFeePer >= 0 && mgmFeePer <= 100);
	}
	public boolean isPropertiesFull() {
		return (numberOfProperties == 5);
	}
	public void removeLastProperty() {
		properties[(numberOfProperties-1)] = null;
		numberOfProperties--;
	}
	public String toString() {
		String propertyString = "";
		for (int i=0;i<numberOfProperties;i++) {
			if (properties[i] != null)
				propertyString += (properties[i].getPropertyName() + "," + properties[i].getCity()
						+ "," + properties[i].getOwner() + "," + properties[i].getRentAmount() + "\n");
		}
		return ("List of the properties for " + name + ", taxID: " + taxID + "\n"
				+ "______________________________________________________\n"
				+ propertyString
				+ "______________________________________________________\n\n"
				+ " total management Fee: " + (getTotalRent() * 0.01 * mgmFeePer));
	}
}
