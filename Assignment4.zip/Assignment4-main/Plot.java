/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description: Hold information & processes for a plot of land including methods to determine if the plot is overlapping another plot
 * Due: 10/24/2022
 * Platform/compiler: Eclipse IDE - Java
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/
public class Plot {
	// Fields
	private int x,y,width,depth;
	
	// Constructors
	public Plot(){
		x=0;
		y=0;
		width=1;
		depth=1;
	}
	public Plot(int x,int y, int width, int depth){
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	public Plot (Plot other){
		this.x = other.getX();
		this.y = other.getY();
		this.width = other.getWidth();
		this.depth = other.getDepth();
	}
	
	// Setters/getters
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getDepth() {
		return depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	// Methods
	public boolean overlaps(Plot other) {
		if (this.x < other.getX() && this.y < other.getY()) {
			if ((this.x + this.width) > other.getX() && this.y + this.depth > other.getY())
				return true;
			else return false;
		}
		if (this.x > other.getX() && this.y < other.getY()) {
			if ((other.getX() + other.getWidth()) > this.x && (this.y + this.depth) > other.getY())
				return true;
			else return false;
		}
		if (this.x < other.getX() && this.y > other.getY()) {
			if ((this.x + this.width) > other.getX() && (other.getY() + other.getDepth()) > this.y)
				return true;
			else return false;
		}
		if (this.x > other.getX() && this.y > other.getY()) {
			if ((other.getX() + other.getWidth()) > this.x && (other.getY() + other.getDepth()) > this.y)
				return true;
			else return false;
		}
		if (this.x == other.getX() && this.y < other.getY()) {
			if (this.y + this.depth > other.getY())
				return true;
			else return false;
		}
		if (this.x == other.getX() && this.y > other.getY()) {
			if (other.getY() + other.getDepth() > this.y)
				return true;
			else return false;
		}
		if (this.y == other.getY() && this.x < other.getX()) {
			if (this.x + this.width > other.getX())
				return true;
			else return false;
		}
		if (this.y == other.getY() && this.x > other.getX()) {
			if (other.getX() + other.getWidth() > this.x)
				return true;
			else return false;
		}
		if (this.y == other.getY() && this.x == other.getX())
			return true;
		return true;
	}
	public boolean encompasses(Plot other) {
		if (this.x <= other.getX() && this.y <= other.getDepth() && (this.x + this.width) >= (other.getX() + other.getWidth()) && (this.y + this.depth) >= (other.getY() + other.getDepth()))
			return true;
		else return false;
	}
	public String toString() {
		return (this.x + "," + this.y + "," + this.width + "," + this.depth);
	}
}
