import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlotTestStudent {

	Plot pl;
	
	@BeforeEach
	void setUp() throws Exception {
		pl = new Plot(1,2,3,4);
	}

	@AfterEach
	void tearDown() throws Exception {
		pl = null;
	}

	@Test
	void testPlot() {
		Plot p = new Plot();
		assertTrue(p.getX() == 0 && p.getY() == 0 && p.getWidth() == 1 && p.getDepth() == 1);
	}

	@Test
	void testPlotIntIntIntInt() {
		Plot p = new Plot(2,4,6,8);
		assertTrue(p.getX() == 2 && p.getY() == 4 && p.getWidth() == 6 && p.getDepth() == 8);
	}

	@Test
	void testPlotPlot() {
		Plot p = new Plot(pl);
		assertTrue(p != pl && p.getX() == pl.getX() && p.getY() == pl.getY() && p.getWidth() == pl.getWidth() && p.getDepth() == pl.getDepth());
	}

	@Test
	void testGetX() {
		assertTrue(pl.getX() == 1);
	}

	@Test
	void testSetX() {
		pl.setX(5);
		assertTrue(pl.getX() == 5);
	}

	@Test
	void testGetY() {
		assertTrue(pl.getY() == 2);
	}

	@Test
	void testSetY() {
		pl.setY(6);
		assertTrue(pl.getY() == 6);
	}

	@Test
	void testGetWidth() {
		assertTrue(pl.getWidth() == 3);
	}

	@Test
	void testSetWidth() {
		pl.setWidth(7);
		assertTrue(pl.getWidth() == 7);
	}

	@Test
	void testGetDepth() {
		assertTrue(pl.getDepth() == 4);
	}

	@Test
	void testSetDepth() {
		pl.setDepth(8);
		assertTrue(pl.getDepth() == 8);
	}

	@Test
	void testOverlaps() {
		Plot p = new Plot(1,3,2,8);
		assertTrue(p.overlaps(pl));
	}

	@Test
	void testEncompasses() {
		Plot p = new Plot(0,0,8,8);
		assertTrue(p.encompasses(pl));
	}

	@Test
	void testToString() {
		assertTrue(pl.toString().equals("1,2,3,4"));
	}

}
