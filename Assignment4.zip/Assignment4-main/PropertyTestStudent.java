import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PropertyTestStudent {

	Property prop;
	@BeforeEach
	void setUp() throws Exception {
		prop = new Property("CMSC","Germantown",100,"Archer",1,1,5,5);
	}

	@AfterEach
	void tearDown() throws Exception {
		prop = null;
	}

	@Test
	void testProperty() {
		Property p = new Property();
		assertTrue(p.getPropertyName() == "" && p.getCity() == "" && p.getOwner() == "" && p.getRentAmount() == 0);
	}

	@Test
	void testPropertyStringStringDoubleString() {
		Property p = new Property("Name","City",100,"Owner");
		assertTrue(p.getPropertyName() == "Name" && p.getCity() == "City" && p.getOwner() == "Owner" && p.getRentAmount() == 100);
	}

	@Test
	void testPropertyStringStringDoubleStringIntIntIntInt() {
		Property p = new Property("Name","City",100,"Owner",1,2,3,4);
		assertTrue(p.getPropertyName() == "Name" && p.getCity() == "City" && p.getOwner() == "Owner" && p.getRentAmount() == 100 &&
				p.getPlot().getX() == 1 && p.getPlot().getY() == 2 && p.getPlot().getWidth() == 3 && p.getPlot().getDepth() == 4);
	}

	@Test
	void testPropertyProperty() {
		Property p = new Property(prop);
		assertTrue(p != prop && p.getPropertyName() == "CMSC" && p.getCity() == "Germantown" && p.getOwner() == "Archer" && p.getRentAmount() == 100 &&
				p.getPlot().getX() == 1 && p.getPlot().getY() == 1 && p.getPlot().getWidth() == 5 && p.getPlot().getDepth() == 5);
	}

	@Test
	void testGetPropertyName() {
		assertTrue(prop.getPropertyName() == "CMSC");
	}

	@Test
	void testGetCity() {
		assertTrue(prop.getCity() == "Germantown");
	}

	@Test
	void testGetOwner() {
		assertTrue(prop.getOwner() == "Archer");
	}

	@Test
	void testGetRentAmount() {
		assertTrue(prop.getRentAmount() == 100);
	}

	@Test
	void testGetPlot() {
		assertTrue(prop.getPlot().getX() == 1 && prop.getPlot().getY() == 1 && prop.getPlot().getWidth() == 5 && prop.getPlot().getDepth() == 5);
	}

	@Test
	void testToString() {
		System.out.println(prop.toString());
		assertTrue(prop.toString().equals("CMSC,Germantown,Archer,100.0"));
	}

}
