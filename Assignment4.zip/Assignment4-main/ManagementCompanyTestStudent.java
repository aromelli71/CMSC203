import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ManagementCompanyTestStudent {
	
	ManagementCompany manCo;

	@BeforeEach
	void setUp() throws Exception {
		manCo = new ManagementCompany("CMSC","123456",50,1,1,5,5);
	}

	@AfterEach
	void tearDown() throws Exception {
		manCo = null;
	}

	@Test
	void testManagementCompany() {
		ManagementCompany m = new ManagementCompany();
		assertTrue(m.getName().equals("") && m.getTaxID().equals(""));
		assertTrue(m.getMgmFeePer() == 0 && m.getPropertiesCount() == 0);
		assertTrue(m.getPlot().getX() == 0 && m.getPlot().getY() == 0 && m.getPlot().getWidth() == 10 && m.getPlot().getDepth() == 10);
		assertTrue(m.getProperties() != null);
	}

	@Test
	void testManagementCompanyStringStringDouble() {
		ManagementCompany m = new ManagementCompany("CMSC","123456",50);
		assertTrue(m.getName().equals("CMSC") && m.getTaxID().equals("123456"));
		assertTrue(m.getMgmFeePer() == 50 && m.getPropertiesCount() == 0);
		assertTrue(m.getPlot().getX() == 0 && m.getPlot().getY() == 0 && m.getPlot().getWidth() == 10 && m.getPlot().getDepth() == 10);
		assertTrue(m.getProperties() != null);
	}

	@Test
	void testManagementCompanyStringStringDoubleIntIntIntInt() {
		ManagementCompany m = new ManagementCompany("CMSC","123456",50,1,2,3,4);
		assertTrue(m.getName().equals("CMSC") && m.getTaxID().equals("123456"));
		assertTrue(m.getMgmFeePer() == 50 && m.getPropertiesCount() == 0);
		assertTrue(m.getPlot().getX() == 1 && m.getPlot().getY() == 2 && m.getPlot().getWidth() == 3 && m.getPlot().getDepth() == 4);
		assertTrue(m.getProperties() != null);
	}

	@Test
	void testManagementCompanyManagementCompany() {
		ManagementCompany m = new ManagementCompany(manCo);
		assertTrue(m != manCo);
		assertTrue(m.getName().equals(manCo.getName()) && m.getTaxID().equals(manCo.getTaxID()));
		assertTrue(m.getMgmFeePer() == manCo.getMgmFeePer() && m.getPropertiesCount() == manCo.getPropertiesCount());
		assertTrue(m.getPlot().getX() == manCo.getPlot().getX() && m.getPlot().getY() == manCo.getPlot().getY() &&
				m.getPlot().getWidth() == manCo.getPlot().getWidth() && m.getPlot().getDepth() == manCo.getPlot().getDepth());
		assertTrue(m.getProperties() != null);
	}

	@Test
	void testGetName() {
		assertTrue(manCo.getName().equals("CMSC"));
	}

	@Test
	void testGetTaxID() {
		assertTrue(manCo.getTaxID().equals("123456"));
	}

	@Test
	void testGetMgmFeePer() {
		assertTrue(manCo.getMgmFeePer() == 50);
	}

	@Test
	void testGetProperties() {
		Property house = new Property("propName","propCity",200,"propOwner");
		manCo.addProperty(house);
		assertTrue(manCo.getProperties()[0].getPropertyName() == house.getPropertyName());
	}

	@Test
	void testGetPlot() {
		assertTrue(manCo.getPlot().getX() == 1 && manCo.getPlot().getY() == 1 && manCo.getPlot().getWidth() == 5 &&
				manCo.getPlot().getDepth() == 5);
	}

	@Test
	void testGetPropertiesCount() {
		manCo.addProperty(new Property("Name","City",100,"Owner",1,1,1,1));
		manCo.addProperty(new Property("Name","City",200,"Owner",1,2,1,1));
		assertTrue(manCo.getPropertiesCount() == 2);
	}

	@Test
	void testAddPropertyStringStringDoubleString() {
		manCo.addProperty("Name1", "City1", 400, "Owner1");
		assertTrue(manCo.getProperties()[0].getPropertyName() == "Name1" &&
				manCo.getProperties()[0].getCity() == "City1" && manCo.getProperties()[0].getRentAmount() == 400
				&& manCo.getProperties()[0].getOwner() == "Owner1");
	}

	@Test
	void testAddPropertyStringStringDoubleStringIntIntIntInt() {
		manCo.addProperty("Name2", "City2", 600, "Owner2", 1,2,3,4);
		assertTrue(manCo.getProperties()[0].getPropertyName() == "Name2" &&
				manCo.getProperties()[0].getCity() == "City2" && manCo.getProperties()[0].getRentAmount() == 600
				&& manCo.getProperties()[0].getOwner() == "Owner2" && manCo.getProperties()[0].getPlot().getX() == 1 &&
				manCo.getProperties()[0].getPlot().getY() == 2 && manCo.getProperties()[0].getPlot().getWidth() == 3 &&
				manCo.getProperties()[0].getPlot().getDepth() == 4);
	}

	@Test
	void testAddPropertyProperty() {
		Property house = new Property("propName","propCity",200,"propOwner");
		manCo.addProperty(house);
		assertTrue(manCo.getProperties()[0].getPropertyName() == house.getPropertyName() &&
				manCo.getProperties()[0].getCity() == house.getCity() && manCo.getProperties()[0].getRentAmount() == house.getRentAmount()
				&& manCo.getProperties()[0].getOwner() == house.getOwner());
	}

	@Test
	void testGetHighestRentPropperty() {
		manCo.addProperty("Name1", "City1", 400, "Owner1",1,1,1,1);
		manCo.addProperty("Name2", "City2", 600, "Owner2",1,2,1,1);
		assertTrue(manCo.getHighestRentPropperty().getPropertyName() == manCo.getProperties()[1].getPropertyName());
	}

	@Test
	void testGetTotalRent() {
		manCo.addProperty("Name1", "City1", 400, "Owner1",1,1,1,1);
		manCo.addProperty("Name2", "City2", 600, "Owner2",1,2,1,1);
		assertTrue(manCo.getTotalRent() == 1000);
	}

	@Test
	void testIsManagementFeeValid() {
		ManagementCompany m = new ManagementCompany("MC","Rockville",300);
		assertTrue(manCo.isManagementFeeValid());
		assertFalse(m.isManagementFeeValid());
	}

	@Test
	void testIsPropertiesFull() {
		assertFalse(manCo.isPropertiesFull());
		manCo.addProperty(new Property("Name","City",100,"Owner",1,1,1,1));
		manCo.addProperty(new Property("Name","City",200,"Owner",1,2,1,1));
		manCo.addProperty(new Property("Name","City",300,"Owner",1,3,1,1));
		manCo.addProperty(new Property("Name","City",400,"Owner",2,2,1,1));
		manCo.addProperty(new Property("Name","City",500,"Owner",2,3,1,1));
		assertTrue(manCo.isPropertiesFull());
	}

	@Test
	void testRemoveLastProperty() {
		manCo.addProperty(new Property("Name","City",100,"Owner",1,1,1,1));
		manCo.addProperty(new Property("Name","City",200,"Owner",1,2,1,1));
		manCo.removeLastProperty();
		assertTrue(manCo.getProperties()[1] == null);
	}

	@Test
	void testToString() {
		String correctString = ("List of the properties for CMSC, taxID: 123456\n"
				+ "______________________________________________________\n"
				+ "Name1,City1,Owner1,400.0\n"
				+ "Name2,City2,Owner2,600.0\n"
				+ "______________________________________________________\n\n"
				+ " total management Fee: 500.0");
		
		manCo.addProperty("Name1", "City1", 400, "Owner1",1,2,1,1);
		manCo.addProperty("Name2", "City2", 600, "Owner2",2,3,1,1);
		System.out.println(manCo.toString());
		assertTrue(manCo.toString().equals(correctString));
	}

}
