/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description: Hold information & processes for a property, including the property's name, owner, rent, and land plot
 * Due: 10/24/2022
 * Platform/compiler: Eclipse IDE - Java
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/

public class Property {
	// Fields
	private String propertyName, city ,owner;
	private double rentAmount;
	private Plot  plot;
	
	// Constructors
	public Property(){
		propertyName = city = owner = "";
		rentAmount = 0;
		plot = new Plot();
	}
	public Property(String propertyName, String city, double rentAmount, String owner){
		this.propertyName = propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
		plot = new Plot();
	}
	public Property(String propertyName, String city, double rentAmount, String owner, int x,int y, int width, int depth){
		this.propertyName = propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
		plot = new Plot(x,y,width,depth);
	}
	public Property(Property otherProperty){
		propertyName = otherProperty.getPropertyName();
		city = otherProperty.getCity();
		rentAmount = otherProperty.rentAmount;
		owner = otherProperty.getOwner();
		plot = new Plot(otherProperty.getPlot());
	}
	
	// Setters / Getters
	public String getPropertyName() {
		return propertyName;
	}
	public String getCity() {
		return city;
	}
	public String getOwner() {
		return owner;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public Plot getPlot() {
		return new Plot(plot);
	}
	
	// Method(s)
	public String toString() {
		return (this.propertyName + "," + this.city + "," + this.owner + "," + this.rentAmount);
	}
}
