import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public class CryptoManagerTestStudent {

	@BeforeEach
	public void setUp() throws Exception {
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

	@Test
	public void testStringInBounds() {
		assertTrue(CryptoManager.isStringInBounds("THIS SHOULD WORK"));
		assertFalse(CryptoManager.isStringInBounds("this should not work due to lowercase letters"));
	}

	@Test
	public void testEncryptCaesar() {
		assertTrue("UIJT!JT!B!QMBJO!UFYU!TUSJOH".equals(CryptoManager.caesarEncryption("THIS IS A PLAIN TEXT STRING", 65)));
		assertTrue("ACBH;CA9FMT7C@@9;9".equals(CryptoManager.caesarEncryption("MONTGOMERY COLLEGE", 52)));
	}

	@Test
	public void testDecryptCaesar() {
		assertTrue("CAESARDECRYPTION".equals(CryptoManager.caesarDecryption("315C1B453BI@D9?>", 48)));
		assertTrue("FUNNY MESSAGE".equals(CryptoManager.caesarDecryption("N]VV!(UM[[IOM", 8)));
	}

	@Test
	public void testEncryptBellaso() {
		assertTrue("L-_LNR3FRZ#XWR%V".equals(CryptoManager.bellasoEncryption("I LIKE COMPUTERS", "CMSC")));
		assertTrue("MSW[_[2J-9ZWJ,]".equals(CryptoManager.bellasoEncryption("JAVAFX IS WEIRD", "CRAZY")));

	}

	@Test
	public void testDecryptBellaso() {
		assertTrue("BELLASOCIPHER".equals(CryptoManager.bellasoDecryption("CU\\XFT_SUUIU\"", "APPLE")));
		assertTrue("SECRET MESSAGE".equals(CryptoManager.bellasoDecryption(" TU%J!/_XX PYX", "MORSE")));

	}

}
