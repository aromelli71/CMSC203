/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description: Encrypt and decrypt messages using the Caesar Cipher and Bellaso Cipher
 * Due: 10/05/2022
 * Platform/compiler: Eclipse IDE 2022 - Java
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/

/**
 * This is a utility class that encrypts and decrypts a phrase using two
 * different approaches. The first approach is called the Caesar Cipher and is a
 * simple �substitution cipher� where characters in a message are replaced by a
 * substitute character. The second approach, due to Giovan Battista Bellaso,
 * uses a key word, where each character in the word specifies the offset for
 * the corresponding character in the message, with the key word wrapping around
 * as needed.
 * 
 * @author Farnaz Eivazi
 * @version 7/16/2022
 */
public class CryptoManager {
	
	private static final char LOWER_RANGE = ' ';
	private static final char UPPER_RANGE = '_';
	private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_RANGE and UPPER_RANGE characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean isStringInBounds (String plainText) {
		for (int i=0;i<plainText.length();i++)											// For each character in the given string
			if (plainText.charAt(i) < LOWER_RANGE || plainText.charAt(i) > UPPER_RANGE)	// If the character is outside the allowable bounds
				return false;															// Return false, otherwise return true
		return true;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String caesarEncryption(String plainText, int key) {
		if (!isStringInBounds(plainText))
			return "The selected string is not in bounds, Try again.";	// Ensure that all string characters are allowable
		while (key > UPPER_RANGE)										// If the key is larger than the upper bound,
			key -= RANGE;												// Decrease the key by the range until it is acceptable
		String output = "";
        for (int i=0;i<plainText.length();i++){							// For each character in the given string
            char temp = plainText.charAt(i);
            temp += key;												// take the character, add the key value
            while (temp > UPPER_RANGE)									// Ensure that the character is still in range
                temp -= RANGE;
            output += temp;												// Add the character to the output string
        }
        return output;
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String bellasoEncryption (String plainText, String bellasoStr) {
		if (!isStringInBounds(plainText))
			return "The selected string is not in bounds, Try again.";	// Ensure that all given characters are in bounds
		int address = 0;				
        while (bellasoStr.length() < plainText.length())				// If needed, extend the cipher to the length of the text
            bellasoStr += bellasoStr.charAt(address++);
        String encryptedText = "";
        for (int i=0;i<plainText.length();i++) {						// For each character in given string
            int tempNum = plainText.charAt(i) + bellasoStr.charAt(i);	// Add the corresponding cipher value to the character
            while (tempNum > UPPER_RANGE)								// Ensure it is still in range or adjust accordingly
                tempNum -= RANGE;
            char tempChar = (char)tempNum;
            encryptedText += tempChar;									// Add character to output string
        }
        return encryptedText;
	}
	
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String caesarDecryption (String encryptedText, int key) {
		if (!isStringInBounds(encryptedText))
			return "The selected string is not in bounds, Try again.";	// Ensure that all string characters are allowable
		while (key > UPPER_RANGE)										// If the key is larger than the upper bound,
			key -= RANGE;												// Decrease the key by the range until it is acceptable
		String output = "";
        for (int i=0;i<encryptedText.length();i++){						// For each character in the given string
            char temp = encryptedText.charAt(i);
            temp -= key;												// take the character, subtract the key value
            while (temp < LOWER_RANGE) {								// Ensure that the character is still in range
                temp += RANGE;
            }
            output += temp;												// Add the character to the output string
        }
        return output;
	}
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String bellasoDecryption(String encryptedText, String bellasoStr) {
		if (!isStringInBounds(encryptedText))
			return "The selected string is not in bounds, Try again.";		// Ensure that all given characters are in bounds
		int address = 0;
        while (bellasoStr.length() < encryptedText.length())				// If needed, extend the cipher to the length of the text
            bellasoStr += bellasoStr.charAt(address++);
        String plainText = "";
        for (int i=0;i<encryptedText.length();i++) {						// For each character in given string
            int tempNum = encryptedText.charAt(i) - bellasoStr.charAt(i);	// Subtract the corresponding cipher value to the character
            while (tempNum < LOWER_RANGE)									// Ensure it is still in range or adjust accordingly
                tempNum += RANGE;
            char tempChar = (char)tempNum;
            plainText += tempChar;											// Add character to output string
        }
        return plainText;
	}
}
